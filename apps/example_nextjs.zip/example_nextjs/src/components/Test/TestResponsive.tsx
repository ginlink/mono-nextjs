import { Box } from '@ginlink/uilib'
import React from 'react'

export default function TestResponsive() {
  return <Box m={[100, null, null, 100]}>Box</Box>
}
